package oitkmg.project2;

import org.junit.Test;

import java.util.Calendar;

import static org.junit.Assert.*;

/**
 * Class is used to test the isValid() method of the Date class.
 * @author Kevin George, Omar Talaat
 */
public class JUnitTest {

    /**
     * Test valid date.
     */
    @org.junit.Test
    public void test_valid_date(){
        Date d2 = new Date("1/1/2000");
        assertTrue(d2.isValid());
        boolean expectedOutput = true;
        boolean actualOutput = d2.isValid();
        assertEquals(expectedOutput, actualOutput);
    }

    /**
     *Test days for a non leap year in February
     */
    @org.junit.Test
    public void test_days_in_Feb_nonLeap(){
        Date d1 = new Date("2/29/2011");
        assertFalse(d1.isValid());
        boolean expectedOutput = false;
        boolean actualOutput = d1.isValid();
        assertEquals(expectedOutput, actualOutput);

        Date d2 = new Date("2/28/2013");
        assertTrue(d2.isValid());
        expectedOutput = true;
        actualOutput = d2.isValid();
        assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test valid range for the month.
     */
    @org.junit.Test
    public void test_month_range(){
        Date d1 = new Date("-1/2/2000");
        assertFalse(d1.isValid());
        boolean expectedOutput = false;
        boolean actualOutput = d1.isValid();
        assertEquals(expectedOutput, actualOutput);

        Date d2 = new Date("13/1/2000");
        assertFalse(d2.isValid());
        actualOutput = d2.isValid();
        assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test valid day range for the month.
     */
    @org.junit.Test
    public void test_days_in_month(){
        Date d1 = new Date("1/32/2000");
        assertFalse(d1.isValid());
        boolean expectedOutput = false;
        boolean actualOutput = d1.isValid();
        assertEquals(expectedOutput, actualOutput);

        Date d2 = new Date("9/31/2000");
        assertFalse(d2.isValid());
        actualOutput = d2.isValid();
        assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test negative month or year.
     */
    @org.junit.Test
    public void test_negative_year_or_month(){
        Date d1 = new Date("1/-3/0");
        assertFalse(d1.isValid());
        boolean expectedOutput = false;
        boolean actualOutput = d1.isValid();
        assertEquals(expectedOutput, actualOutput);

        Date d2 = new Date("1/1/-1");
        assertFalse(d2.isValid());
        actualOutput = d2.isValid();
        assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test valid leap year.
     */
    @org.junit.Test
    public void valid_leap_year(){
        Date d1 = new Date("2/29/2020");
        assertTrue(d1.isValid());
        boolean expectedOutput = true;
        boolean actualOutput = d1.isValid();
        assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test membership fee for premium member.
     */
    @Test
    public void membershipFee() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 1);
        Premium p = new Premium("John", "Doe", new Date("01/01/2000"),
                new Date(cal), Location.BRIDGEWATER);
        double expectedOutput = 659.89;
        double actualOutput = p.membershipFee();
        assertEquals(expectedOutput, actualOutput, 0);
    }

    /**
     * Test checking in and checking out a member from a test fitness class.
     */
    @Test
    public void test_check_in_out_member(){
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 1);
        String fname = "John", lname = "Doe";
        Date dob = new Date("01/01/2000"), expire = new Date(cal);
        Location loc = Location.BRIDGEWATER;
        Member m = new Member(fname, lname, dob, expire, loc);
        boolean expectedOutput = true;
        FitnessClass fitnessClass = new FitnessClass("Pilates",
                "Jennifer", "morning", loc);
        fitnessClass.checkInMember(m);
        boolean actualOutput = fitnessClass.memberExists(m);
        assertEquals(expectedOutput, actualOutput);

        expectedOutput = false;
        fitnessClass.unCheckInMember(m);
        actualOutput = fitnessClass.memberExists(m);
        assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test guest check in and check out.
     */
    @Test
    public void test_check_in_out_guest(){
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 1);
        String fname = "John", lname = "Doe";
        Date dob = new Date("01/01/2000"), expire = new Date(cal);
        Location loc = Location.BRIDGEWATER;
        Premium m = new Premium(fname, lname, dob, expire, loc);
        Guest g = new Guest(m);
        boolean expectedOutput = true;
        FitnessClass fitnessClass = new FitnessClass("Pilates",
                "Jennifer", "morning", loc);
        fitnessClass.checkInGuest(m);
        Guest[] guests = fitnessClass.getGuests().toArray(new Guest[0]);
        boolean actualOutput = false;
        for (Guest guest : guests) {
            if (g.equals(guest)) {
                actualOutput = true;
                break;
            }
        }
        assertEquals(expectedOutput, actualOutput);

        expectedOutput = false;
        fitnessClass.checkOutGuest(m);
        guests = fitnessClass.getGuests().toArray(new Guest[0]);
        actualOutput = false;
        for(int i = 0; i < guests.length; ++i){
            if(g.equals(guests[i])){
                actualOutput = true;
                break;
            }
        }
        assertEquals(expectedOutput, actualOutput);
    }
}